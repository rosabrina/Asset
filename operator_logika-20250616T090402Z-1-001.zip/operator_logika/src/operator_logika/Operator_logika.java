/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operator_logika;

/**
 *mengerjakan tugas operator logika
 * @author Rosabrina Noviyanti
 */
public class Operator_logika {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Buat variabel
        boolean b1 = 5 < 10;
        boolean b2 = 9 > 11;
        boolean b3 = !b1;
        //kebalikan dari b1
        boolean b4 = !b2;
        //kebalikan dari nilai b2
        
        // Tes Logika AND
        boolean TesAND1 = b1 & b2;
        //bernilai  true jika b1 atau b2 bernilai true
        boolean TesAND2 = b1 && b2;
        //bernilai true jika b1 dan b2 bernilai true
        boolean TesAND3 = b1 && b3;
        //bernilai true jika b1 dan b3 bernilai true
        boolean TesAND4 = b1 && b4;
        //bernilai true jika b1 dan b4 bernilai true
        
        // Tes Logika OR
        boolean TesOR1 = b1 | b2;
        //bernilai false jika b1 dan b2 nya bernilai false
        boolean TesOR2 = b1 || b2;
         //bernilai false jika b1 dan b2 nya bernilai false
        boolean TesOR3 = b1 || b3;
         //bernilai false jika b1 dan b3 nya bernilai false
        boolean TesOR4 = b1 || b4;
         //bernilai false jika b1 dan b2 nya bernilai false
        
        // Tes Logika XOR
        boolean TesXOR1 = b1 ^ b2;
        //bernilai true jika b1 tidak sama nilainya dengan b2
        boolean TesXOR2 = b1 ^ b3;
        //bernilai true jika b1 tidak sama nilainya dengan b3
        boolean TesXOR3 = b1 ^ b4;
        //bernilai true jika b1 tidak sama nilainya dengan b4
        
        // Print
        System.out.println("Tes AND 1 = " + TesAND1);
        System.out.println("Tes AND 2 = " + TesAND2);
        System.out.println("Tes AND 3 = " + TesAND3);
        System.out.println("Tes AND 4 = " + TesAND4);
        System.out.println("Tes OR 1 = " + TesOR1);
        System.out.println("Tes OR 2 = " + TesOR2);
        System.out.println("Tes OR 3 = " + TesOR3);
        System.out.println("Tes OR 4 = " + TesOR4);
        System.out.println("Tes XOR 1 = " + TesXOR1);
        System.out.println("Tes XOR 2 = " + TesXOR2);
        System.out.println("Tes XOR 3 = " + TesXOR3);
    }
    
}
